export const workPermit = [
  "Hot",
  "Height/Civil",
  "Electric",
  "LPG",
  "Confined space",
  "Special Equipment",
];
