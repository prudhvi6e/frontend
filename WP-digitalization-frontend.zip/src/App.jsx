import AppRoutes from './Routes';
import "bootstrap-icons/font/bootstrap-icons";


function App() {
  return (
      <AppRoutes/>
  );
}

export default App;
